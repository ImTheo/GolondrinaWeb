import React from "react";
export function AdminReservations() {
    return ( 
    <div>
        <h2>RESERVACIONES</h2>
        <br />
        <table className="table table-sm" border={1} bordercolor="grey">
          <thead>
            <tr>
              <th scope="col">Nombre</th>
              <th scope="col">Correo Electrónico</th>
              <th scope="col">Número telefónico</th>
              <th scope="col">Habitación</th>
              <th scope="col">Fecha de partida</th>
              <th scope="col">Fecha de retorno</th>
              <th scope="col">Servicios Extras</th>
              <th scope="col">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr>

            </tr>
            <tr>
              <td>
                <a className="edit" href>
                  Editar
                </a>
              </td>
              <td>
                <a className="edit" href>
                  Eliminar
                </a>
              </td>
            </tr>
          </tbody>
          <tbody></tbody>
        </table>
    </div> );
}

export default AdminReservations;