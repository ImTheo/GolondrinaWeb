import React from "react";
export function AdminActivities() {
    return ( 
        <><h2>ACTIVIDADES</h2><div className="container">
            <br />
            <br />
            <div className="row">
                <div className="col">
                    <div className="form-group">
                        <form action="insertRoom.php" method="POST">
                            <br />
                            <label htmlFor="id">ID</label>
                            <br />
                            <input
                                classname="form-control"
                                type="text"
                                id="id"
                                className="rounded"
                                name="id"
                                required="required"
                                placeholder="Nombre" />

                            <label htmlFor="nombreHabitacion">Nombre</label>
                            <br />
                            <input
                                classname="form-control"
                                className="rounded"
                                type="text"
                                id="nombreHabitacion"
                                name="nombreHabitacion"
                                required="required"
                                placeholder="Nombre" />
                            <h5>Capacidad</h5>
                            <br />
                            <div className="row">
                                <div className="col">
                                    <label htmlFor="adultos">Adultos</label>
                                    <br />
                                    <input
                                        type="number"
                                        classname="form-control"
                                        className="rounded"
                                        id="adultos"
                                        name="adultos"
                                        requiered="requiered"
                                        min="{0}" />
                                    <br />
                                    <br />
                                </div>
                                <div className="col">
                                    <label htmlFor="ninos">Niños</label>
                                    <br />
                                    <input
                                        type="number"
                                        classname="form-control"
                                        id="ninos"
                                        className="rounded"
                                        name="ninos"
                                        requiered="requiered"
                                        min="{0}" />
                                    <br />
                                </div>
                            </div>
                            <br />
                            <br />
                            <label htmlFor="descripcion">Descripcion</label>
                            <br />
                            <input
                                classname="form-control"
                                type="text"
                                id="descripcion"
                                className="rounded"
                                name="descripcion"
                                required="required"
                                placeholder="Descripcion" />
                            <br />
                            <br />
                            <input
                                className="boton"
                                type="submit"
                                required="required"
                                name="Enviar Datos" />
                            <br />
                        </form>
                        <br />
                        <br />
                    </div>
                </div>
            </div>
        </div><table className="table table-sm" border={1} bordercolor="grey">
                <thead>
                    <tr>
                        <th scope="col">Modalidad</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Imagen</th>
                        <th scope="col">Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>

                    </tr>
                    <tr>
                        <td>
                            <a className="edit" href>
                                Editar
                            </a>
                        </td>
                        <td>
                            <a className="edit" href>
                                Eliminar
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table></>
     );
}

export default AdminActivities;